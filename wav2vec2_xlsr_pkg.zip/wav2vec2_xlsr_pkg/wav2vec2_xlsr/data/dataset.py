from __future__ import annotations
from dataclasses import dataclass
from pathlib import Path
from typing import List, Dict, Any
import pandas as pd
import torchaudio
import torch

@dataclass
class AudioItem:
    path: str
    text: str

class ASRDataset(torch.utils.data.Dataset):
    def __init__(self, csv_path: str, sample_rate: int = 16000):
        self.df = pd.read_csv(csv_path)
        if not {"path","text"}.issubset(self.df.columns):
            raise ValueError("CSV must contain columns: path,text")
        self.sample_rate = sample_rate

    def __len__(self) -> int:
        return len(self.df)

    def __getitem__(self, idx: int) -> Dict[str, Any]:
        row = self.df.iloc[idx]
        audio_path = row["path"]
        text = str(row["text"])
        wav, sr = torchaudio.load(audio_path)
        if sr != self.sample_rate:
            wav = torchaudio.functional.resample(wav, sr, self.sample_rate)
        wav = wav.mean(dim=0).unsqueeze(0)  # mono [1, T]
        return {"input_values": wav.squeeze(0), "text": text}
