#!/usr/bin/env python
from wav2vec2_xlsr.engine.trainer import main
if __name__ == "__main__":
    main()
