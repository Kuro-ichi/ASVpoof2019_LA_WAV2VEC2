#!/usr/bin/env python
from wav2vec2_xlsr.engine.evaluator import main
if __name__ == "__main__":
    main()
